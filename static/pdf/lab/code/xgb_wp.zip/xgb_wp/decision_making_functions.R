
P_CUTOFF = 0.95 #FIXME

#########################################
### Example Decision Making Dataframe ###
#########################################

generate_V_dataset <- function(kq, pq, pspread, qbqot, oqrot, dqpdt, dqrdt, qbqdt, oqrdt, dqpot, dqrot, confounders_dataset) {
  df = tibble()
  MAX_YTG = 15 #10
  for (ydstogo in 1:MAX_YTG) {
    dfy = tibble(
      yardline_100 = ydstogo:99,
      ydstogo = ydstogo,
      qbq_ot_0_sum = qbqot,
      oq_rot_0_total_sum = oqrot,
      dq_dt_0_againstPass_sum = dqpdt,
      dq_dt_0_againstRun_sum = dqrdt,
      qbq_dt_0_sum = qbqdt,
      oq_rdt_0_sum = oqrdt,
      dq_ot_0_againstPass_sum = dqpot,
      dq_ot_0_againstRun_sum = dqrot,
      kq_0_sum_std = kq,
      pq_0_sum_std = pq,
      posteam_spread = pspread
    )
    df = bind_rows(df, dfy)
  }
  ### crudely, join the confounders dataset row to each row of DF
  df$key = 1
  confounders_dataset$key = 1
  df = df %>% left_join(confounders_dataset) %>% select(-key)
  return(df)
}

# ex2_confounders_dataset = tibble(
#   season=2015, posteam="LAR", home_team="LAR", roof="dome",
#   posteam_timeouts_remaining=3, defteam_timeouts_remaining=3,
#   # half_seconds_remaining = 120, half_sec_rem_std = 1-(120/1800),
#   half_seconds_remaining = 1800, half_sec_rem_std = 0,
#   # half_seconds_remaining = 900, half_sec_rem_std = 1/2,
#   era_A = 3
# )
# ex2 = generate_V_dataset(kq=0, pq=0, oqot=0, dqdt=0, oqdt=0, dqot=0, ex2_confounders_dataset)
# ex2
## View(ex2)


###########################
### First Down EP Model ###
###########################

calculate_V1 <- function(dataset, model_fit, og_method=FALSE, wp) {
  ### calculate the value of having a FIRST DOWN (wth 10 ydstogo, or goal) at the yardlines in DATASET
  dataset = dataset %>% mutate(
    down = 1,
    ydstogo = ifelse(yardline_100 <= 10, yardline_100, 10)
  )

  ### WP
  if (wp) {
    wp_ = predict_probs_xgb(
       model_fit, 
       dataset, 
       xgb_features = get(paste0(V1_model_name_WP, "_features")), 
       wp=TRUE
    )
    return(wp_)
  }
  
  ### EP
  if (og_method) {
    # og_method = "nflFastR"
    og_method = "Burke"
    if (og_method == "Burke") { # Burke 2009 method
      # ep = predict_lm(Burke_model_fit, dataset)
      ep = predict_lm(V1_model_og, dataset)
    } else if (og_method == "nflFastR") { # nflFastR method 
      ep = nflfastR::calculate_expected_points(dataset)$ep
    }
  } else { # EP, our method
    if (V1_model_type_EP == "MLR") {
      ep = predict_mlr_ep(model_fit, dataset, "")$pred
    } else if (V1_model_type_EP == "XGB") {
      ep = predict_ep_xgb(
        model_fit, 
        dataset, 
        xgb_features = get(paste0(V1_model_name_EP, "_features")), 
        model_name = V1_model_name_EP
      )$pred
    }
  }
  ep = ifelse(dataset$yardline_100 <= 0, 7, ifelse(dataset$yardline_100 >= 100, -2, ep))
  return(ep)
}

# ### check
# V1_model_main = fit_our_model(model_name, V1_model_type, DATASET)
# calculate_V1(ex2, V1_model_main)
# calculate_V1(ex2, V1_model_main, og_method = FALSE)

###################################
### Field Goal Probablity Model ###
###################################

P_FG <- function(fg_model_fit, dataset, og_method=FALSE) {
  ### calculate the probability of making a FIELD GOAL at the yardlines in DATASET
  dataset = dataset %>% select(yardline_100, kq_0_sum_std)
  if (!og_method) {
    predict(fg_model_fit, dataset, type="response")
  } else { ### original decision making ignores team quality
    predict(fg_model_og, dataset, type="response")
  }
}

# ### check
# P_FG(fg_model, ex2)
# P_FG(fg_model, ex2, og_method=TRUE)

###################################
### Conversion Probablity Model ###
###################################

P_convert <- function(go_model_fit, dataset, og_method=FALSE) {
  ### calculate the probability of converting a FOURTH DOWN GO ATTEMPT at the ydstogo's in DATASET
  dataset = dataset %>% 
    select(ydstogo, yardline_100, qbq_ot_0_sum, oq_rot_0_total_sum, dq_dt_0_againstPass_sum, dq_dt_0_againstRun_sum) %>%
    mutate(down = 4) 
  if (!og_method) {
    # predict(go_model_fit, xgb.DMatrix(as.matrix(dataset))) ### catalytic xgboost
    predict(go_model_fit, dataset, type="response") ### logistic regression
  } else { ### original decision making ignores team quality
    predict(go_model_og, dataset, type="response") ### logistic regression
  }
}

# ### check
# P_convert(go_model, ex2)
# P_convert(go_model, ex2, og_method=TRUE)

##########################################
### Punt: Expected Next Yardline Model ###
##########################################

E_punt <- function(punt_model_fit, dataset, og_method=FALSE) {
  ### calculate the EXPECTED NEXT YARDLINE of a PUNT at the yardlines in DATASET
  dataset = dataset %>% select(yardline_100, pq_0_sum_std)
  if (!og_method) {
    predict(punt_model_fit, dataset)
  } else { ### original decision making ignores team quality
    predict(punt_model_og, dataset)
  }
}

### check
# E_punt(punt_model, ex2)
# E_punt(punt_model, ex2, og_method=TRUE)

#############################
### Value of Going For It ###
#############################

field_position_switcherooni <- function(dataset, next_ydl_opp, next_score_diff_opp) {
  ### imagine turning it over and the other team getting the ball
  ### switch the dataset to be from the other team's perspective, if they have possession
  dataset_1a = dataset %>% mutate(
    yardline_100 = next_ydl_opp, #####
    score_differential = next_score_diff_opp,
    ### temp
    qbqot = qbq_ot_0_sum,
    oqrot = oq_rot_0_total_sum,
    qbqdt = qbq_dt_0_sum,
    oqrdt = oq_rdt_0_sum,
    dqpdt = dq_dt_0_againstPass_sum,
    dqrdt = dq_dt_0_againstRun_sum,
    dqpot = dq_ot_0_againstPass_sum,
    dqrot = dq_ot_0_againstRun_sum,
    ### switch TQ's
    qbq_ot_0_sum = qbqdt,
    oq_rot_0_total_sum = oqrdt,
    qbq_dt_0_sum = qbqot,
    oq_rdt_0_sum = oqrot,
    dq_dt_0_againstPass_sum = dqpot,
    dq_dt_0_againstRun_sum = dqrot,
    dq_ot_0_againstPass_sum = dqpdt,
    dq_ot_0_againstRun_sum = dqrdt,
    posteam_spread = -posteam_spread,
    ### switch other stuff
    receive_2h_ko = !receive_2h_ko,
    home = !home,
  ) %>% 
    mutate(
      ### switch vars which are derived from other vars
      scoreTimeRatio = compute_scoreTimeRatio(score_differential, game_seconds_remaining),
      Diff_Time_Ratio = score_differential / (exp(-4*elapsed_share)),
      spread_time = posteam_spread * exp(-4*elapsed_share),
    ) %>%
    select(-c(qbqot,oqrot,dqpdt,dqrdt,qbqdt,oqrdt,dqpot,dqrot))
  return(dataset_1a)
}

V_go <- function(dataset, go_model_fit, model_fit, og_method = FALSE, wp, custom_conv_prob=NULL) {
  ### calculate the value of GOING FOR IT at the (yardlines, ydstogo's) in DATASET
  
  ### probability you convert
  pc = P_convert(go_model_fit, dataset, og_method=og_method)
  pc = unname(pc)
  # browser();  dataset = dataset %>% mutate(pc=pc) %>% relocate(pc, .after=ydstogo)
  if (!is.null(custom_conv_prob)) {
    ### use custom conversion probability
    pc = rep(custom_conv_prob, length(pc))
  } 
  
  ### value of a first down if you convert
  dataset_1a = dataset %>% mutate(
    yardline_100 = yardline_100 - ydstogo
  )
  v_convert = calculate_V1(dataset_1a, model_fit, og_method = og_method, wp=wp)
  
  # v_if_score_td = 1 - calculate_V1(
  #   field_position_switcherooni(
  #     dataset, 
  #     next_ydl_opp = 75, # touchback
  #     next_score_diff_opp = -dataset$score_differential - 3
  #   ), model_fit, og_method = og_method, wp=wp
  # )
  # v1a = ifelse(
  #   dataset_1a$yardline_100 <= 0, ### scored a TD
  #   v_if_score_td,
  #   v1a
  # )
  
  ### value of a first down for the other team if you don't convert
  dataset_1b = field_position_switcherooni(
    dataset, 
    next_ydl_opp = 100 - dataset$yardline_100, 
    next_score_diff_opp = -dataset$score_differential
  )
  v_dont_convert = calculate_V1(dataset_1b, model_fit, og_method = og_method, wp=wp)
  if (wp) {
    v_dont_convert = 1 - v_dont_convert
  } else { ### ep
    v_dont_convert = -v_dont_convert
  }
  
  # browser()
  # dataset_1b$v_convert = v_convert
  # dataset_1b$ydl_og = dataset$yardline_100
  # dataset_1b$v_dont_convert = v_dont_convert
  # dataset_1b$sd_og = dataset$score_differential
  # dataset_1b$pc = pc
  # dataset_1b %>% select(game_seconds_remaining, sd_og, ydl_og, ydstogo, pc, v_convert,
  #                       yardline_100, game_seconds_remaining, score_differential, scoreTimeRatio, posteam_spread, v_dont_convert) %>% arrange(game_seconds_remaining)

  # resulting_df = dataset %>% select(yardline_100, ydstogo) %>%
  #   mutate(
  #     ydl_start = yardline_100,
  #     ydl_if_convert = yardline_100 - ydstogo,
  #     ydl_if_dontConvert_opp = 100 - yardline_100,
  #     prob_convert = pc,
  #     value_convert = v1a,
  #     ev_convert = prob_convert*value_convert,
  #     prob_dontConvert = 1-pc,
  #     value_dontConvert = ifelse(wp, 1-v1a, -v1a),
  #     ev_dontConvert = prob_dontConvert*value_dontConvert,
  #     pvmd = prob_convert*(value_convert - value_dontConvert),
  #     v_total = ev_convert + ev_dontConvert
  #   )
  # View(resulting_df)
  # browser()
  list(v_convert=v_convert, v_dont_convert=v_dont_convert, p_convert = pc, wp = pc*v_convert + (1-pc)*v_dont_convert)
  # return(pc*v_convert + (1-pc)*v_dont_convert)
}

# ### check
# V_go(ex2, V1_model_main, og_method = FALSE)
# V_go(ex2, V1_model_main, og_method = TRUE)

#####################
### Value of a FG ###
#####################

V_FG <- function(dataset, fg_model_fit, model_fit, og_method = FALSE, wp) {
  ### calculate the value of kicking a FIELD GOAL at the yardlines in DATASET

  ### probability you make the field goal
  # pfg = suppressWarnings( P_FG(yardline_100, kq) )
  pfg = P_FG(fg_model_fit, dataset, og_method=og_method)
  pfg = unname(pfg)
  
  ### value if you make the field goal
  if (wp) {
    dataset_1a = field_position_switcherooni(
      dataset, 
      next_ydl_opp = 75, # touchback
      next_score_diff_opp = -dataset$score_differential - 3
    )
    v_make_fg = 1 - calculate_V1(dataset_1a, model_fit, og_method = og_method, wp=wp)
  } else { ### ep
    v_make_fg = 3
  }
  
  # browser()
  # dataset_1a$v_make_fg = v_make_fg
  # dataset_1a$sd_og = dataset$score_differential
  # dataset_1a$ydl_og = dataset$yardline_100
  # dataset_1a %>% select(ydl_og, yardline_100, game_seconds_remaining, score_differential, posteam_spread, v_make_fg) %>% arrange(game_seconds_remaining)
  
  ### value of a first down for the other team if you miss the field goal
  dataset_1b = field_position_switcherooni(
    dataset, 
    next_ydl_opp = 100 - dataset$yardline_100, 
    next_score_diff_opp = -dataset$score_differential
  )
  v_miss_fg = calculate_V1(dataset_1b, model_fit, og_method = og_method, wp=wp)
  if (wp) {
    v_miss_fg = 1 - v_miss_fg
  } else { ### ep
    v_miss_fg = -v_miss_fg
  }
  
  list(pfg = pfg, v_make_fg=v_make_fg, v_miss_fg=v_miss_fg, wp=pfg*v_make_fg + (1-pfg)*v_miss_fg)
  # return(pfg*v_make_fg + (1-pfg)*v_miss_fg)
}

# ### check
# V_FG(ex2, V1_model_main, og_method = FALSE)
# V_FG(ex2, V1_model_main, og_method = TRUE)

#######################
### Value of a PUNT ###
#######################

V_punt <- function(dataset, punt_model_fit, model_fit, og_method = FALSE, wp) {
  ### calculate the value of PUNTING at the yardlines in DATASET

    ### value of a first down for the other team at the expected next yardline if you punt
  ### no punting within the 30 yardline (the punt model can't even fit this), so just assume touchback if punt
  # v1a = ifelse(dataset$yardline_100 >= 30, v1a, Inf)
  next_ydl_opp_1a = ifelse(
    dataset$yardline_100 >= 30,
    E_punt(punt_model_fit, dataset, og_method=og_method), 
    75 # touchback
  )
  dataset_1a = field_position_switcherooni(
    dataset, 
    # next_ydl_opp = 75, # touchback 
    next_ydl_opp = next_ydl_opp_1a,
    next_score_diff_opp = -dataset$score_differential
  )
  v1a = calculate_V1(dataset_1a, model_fit, og_method = og_method, wp=wp)
  
  # browser()
  # dataset_1a$v1a = v1a
  # dataset_1a$ydl_og = dataset$yardline_100
  # dataset_1a %>% select(ydl_og, yardline_100, game_seconds_remaining, score_differential, posteam_spread, v1a) %>% arrange(game_seconds_remaining)
  # 
  # dataset_1ab = dataset_1a %>% select(game_seconds_remaining, yardline_100, score_differential, scoreTimeRatio, posteam_spread)
  # v1ab = calculate_V1(dataset_1ab, model_fit, og_method = og_method, wp=wp)
  # dataset_1ab$v1ab = v1ab
  # dataset_1ab$ydl_og = dataset$yardline_100
  # dataset_1ab %>% arrange(game_seconds_remaining)
  
  if (wp) {
    return(1 - v1a)
  } else { ### ep
    return(-v1a)
  }
}

# ### check
# V_punt(ex2, V1_model_main, og_method = FALSE)
# V_punt(ex2, V1_model_main, og_method = TRUE)

#############################################
### Compute the Value of Go, FG, and PUNT ###
#############################################

calculate_Vs <- function(dataset, model_fit, fg_model_fit, punt_model_fit, go_model_fit, og_method = FALSE, wp, custom_conv_prob=NULL) {
  Vgo_lst = V_go(dataset, go_model_fit, model_fit, og_method=og_method, wp=wp, custom_conv_prob=custom_conv_prob)
  Vgo = Vgo_lst$wp
  Vfg_lst = V_FG(dataset, fg_model_fit, model_fit, og_method=og_method, wp=wp)
  Vfg = Vfg_lst$wp
  Vpunt = V_punt(dataset, punt_model_fit, model_fit, og_method=og_method, wp=wp)

  # ### restrict the range
  # Vfg = ifelse(dataset$yardline_100 > 43, NA_real_, Vfg) ###FIXME
  # Vpunt = ifelse(dataset$yardline_100 < 25, NA_real_, Vpunt)
  
  ### decision
  V_scores = tibble(
    Vgo_scores = replace_na(Vgo, -Inf),
    Vfg_scores = replace_na(Vfg, -Inf),
    Vpunt_scores = replace_na(Vpunt, -Inf),
  ) %>% mutate(
    maxcol = max.col(.[,1:3]),
    mincol = max.col(-.[,1:3]),
    secondMaxCol = 1+2+3-maxcol-mincol,
    decision = case_when(maxcol == 1 ~ "Go", maxcol == 2 ~ "FG", maxcol == 3 ~ "Punt", TRUE ~ NA_character_),
    decision_2ndBest = case_when(secondMaxCol == 1 ~ "Go", secondMaxCol == 2 ~ "FG", secondMaxCol == 3 ~ "Punt", TRUE ~ NA_character_),
    decision_3rdBest = case_when(mincol == 1 ~ "Go", mincol == 2 ~ "FG", mincol == 3 ~ "Punt", TRUE ~ NA_character_)
  ) %>% 
  ungroup() %>%
  mutate(
    V_bestDecision = case_when(decision == "Go" ~ Vgo_scores, decision == "FG" ~ Vfg_scores, decision == "Punt" ~ Vpunt_scores, TRUE ~ NA_real_),
    V_2ndbestDecision = case_when(decision_2ndBest == "Go" ~ Vgo_scores, decision_2ndBest == "FG" ~ Vfg_scores, decision_2ndBest == "Punt" ~ Vpunt_scores, TRUE ~ NA_real_),
    V_3rdbestDecision = case_when(decision_3rdBest == "Go" ~ Vgo_scores, decision_3rdBest == "FG" ~ Vfg_scores, decision_3rdBest == "Punt" ~ Vpunt_scores, TRUE ~ NA_real_),
    decision_intensity = V_bestDecision - V_2ndbestDecision
  )
  V_scores
  
  tibble(V_go = Vgo, V_fg = Vfg, V_punt = Vpunt, 
         decision = V_scores$decision, decision_2ndBest = V_scores$decision_2ndBest, decision_3rdBest = V_scores$decision_3rdBest, 
         decision_intensity = V_scores$decision_intensity,
         p_convert = Vgo_lst$p_convert, v_convert = Vgo_lst$v_convert, v_dont_convert = Vgo_lst$v_dont_convert,
         p_fg = Vfg_lst$pfg, v_make_fg = Vfg_lst$v_make_fg, v_miss_fg = Vfg_lst$v_miss_fg)
}

# ### check
# calculate_Vs(ex2, V1_model_main, fg_model, punt_model, go_model, og_method = FALSE)
# calculate_Vs(ex2, V1_model_main, og_method = TRUE)

##################################################################
### Compute the Value of Go, FG, and PUNT using our Bootstrap  ###
##################################################################

calculate_Vs_bootstrap <- function(dataset, wp, b_max=B, custom_conv_prob=NULL) {
  Vs_all = tibble()
  for (b in 0:b_max) {
    print(paste0("evaluate bootstrap b = ", b, " of B = ", b_max))
    ### b^th bootstrapped model fits
    if (wp) {
      V1_wp_model_fit_b = V1_wp_model_fitList_boot[[b+1]]
    } else {
      model_fit_b = V1_model_fitList_boot[[b+1]]
    }
    fg_model_fit_b = fg_model_fitList_boot[[b+1]]
    punt_model_fit_b = punt_model_fitList_boot[[b+1]]
    go_model_fit_b = go_model_fitList_boot[[b+1]]
    
    Vs_b = calculate_Vs(dataset, if (wp) V1_wp_model_fit_b else model_fit_b, fg_model_fit_b, punt_model_fit_b, go_model_fit_b, og_method=FALSE, wp=wp, custom_conv_prob=custom_conv_prob)
    Vs_b$b = b
    Vs_b = Vs_b %>% mutate(i = 1:n())
    Vs_all = bind_rows(Vs_all, Vs_b)
  }
  
  # browser()
  
  ### bootstrapped 4th down decisions!
  Vs_all0 = Vs_all %>% ###filter(i==1) %>%
    group_by(i) %>%
    mutate(
      decision_pointEstimate = decision[1],
      # decision_intensity_pointEstimate = decision_intensity[1],
      num_go = sum(decision == "Go"),
      num_fg = sum(decision == "FG"),
      num_punt = sum(decision == "Punt"),
      boot_prop_go = num_go/n(),
      boot_prop_fg = num_fg/n(),
      boot_prop_punt = num_punt/n(),
    ) %>%
    relocate(decision_pointEstimate, .before=decision) %>%
    rowwise() %>%
    mutate(
      V_gain = case_when(
        decision_pointEstimate == "Go" ~ V_go - max(V_fg, V_punt),
        decision_pointEstimate == "FG" ~ V_fg - max(V_go, V_punt),
        decision_pointEstimate == "Punt" ~ V_punt - max(V_go, V_fg),
      )
    ) %>%
    relocate(V_gain, .after=decision_intensity) %>%
    group_by(i) %>%
    # relocate(decision_intensity_pointEstimate, .after=decision_intensity) %>%
    mutate(
      num_boot_best = num_go*(decision=="Go") + num_fg*(decision=="FG") + num_punt*(decision=="Punt"),
      num_boot_2ndbest = num_go*(decision_2ndBest=="Go") + num_fg*(decision_2ndBest=="FG") + num_punt*(decision_2ndBest=="Punt"),
      num_boot_3rdbest = num_go*(decision_3rdBest=="Go") + num_fg*(decision_3rdBest=="FG") + num_punt*(decision_3rdBest=="Punt"),
      prop_decision = num_boot_best/n(),
      prop_decision_2nd_Best = num_boot_2ndbest/n(),
      prop_decision_3rd_Best = num_boot_3rdbest/n(),
      prop_intensity = prop_decision - prop_decision_2nd_Best
    ) %>% ungroup() 
  Vs_all0
  
  ### get CI from boostrap samples
  Vs_all2 = Vs_all0 %>% group_by(i) %>% 
    summarise(
      V_go = quantile(V_go, probs=c(0.025, 0.5, 0.975), na.rm=TRUE),
      V_fg = quantile(V_fg, probs=c(0.025, 0.5, 0.975), na.rm=TRUE),
      V_punt = quantile(V_punt, probs=c(0.025, 0.5, 0.975), na.rm=TRUE),
      V_decision_intensity = quantile(decision_intensity, probs=c(0.025, 0.5, 0.975), na.rm=TRUE),
      V_gain = quantile(V_gain, probs=c(0.025, 0.5, 0.975), na.rm=TRUE),
      ### V_decision_intensity_pointEstimate = quantile(decision_intensity_pointEstimate, probs=c(0.025, 0.5, 0.975), na.rm=TRUE),
    ) %>% 
    mutate(
      V_go_names = paste0("V_go", c("_L", "_M", "_U")),
      V_fg_names = paste0("V_fg", c("_L", "_M", "_U")),
      V_punt_names = paste0("V_punt", c("_L", "_M", "_U")),
      V_decision_intensity_names = paste0("decision_intensity", c("_L", "_M", "_U")),
      V_gain_names = paste0("V_gain", c("_L", "_M", "_U")),
      # V_go_names = paste0("V_go", c("_L", "", "_U")),
      # V_fg_names = paste0("V_fg", c("_L", "", "_U")),
      # V_punt_names = paste0("V_punt", c("_L", "", "_U"))
    ) %>% ungroup()
  Vs_all2
  V_go_SE = Vs_all2 %>% pivot_wider(names_from = V_go_names, values_from = V_go,i) %>% ungroup()
  V_fg_SE = Vs_all2 %>% pivot_wider(names_from = V_fg_names, values_from = V_fg,i) %>% ungroup()
  V_punt_SE = Vs_all2 %>% pivot_wider(names_from = V_punt_names, values_from = V_punt,i) %>% ungroup()
  V_decision_intensity_SE = Vs_all2 %>% pivot_wider(names_from = V_decision_intensity_names, values_from = V_decision_intensity,i) %>% ungroup()
  V_gain_SE = Vs_all2 %>% pivot_wider(names_from = V_gain_names, values_from = V_gain,i) %>% ungroup()
  Vs_all3 = V_go_SE %>% left_join(V_fg_SE) %>% left_join(V_punt_SE) %>% left_join(V_decision_intensity_SE) %>% left_join(V_gain_SE)
  Vs_all3
  # Vs_all4 = left_join(Vs_all0, Vs_all3, by="i")
  Vs_all4 = left_join(Vs_all0, Vs_all3, by="i")
  Vs_all4
  # Vs_all5 = Vs_all4 %>% filter(b == 0) %>% ### keep only the model from observed data
  #   relocate(V_go, .before = V_go_M) %>% relocate(V_fg, .before = V_fg_M) %>% relocate(V_punt, .before = V_punt_M)
  Vs_all5 = Vs_all4 %>% filter(b == 0) ### 
  Vs_all5
  Vs_all6 = Vs_all5 %>% 
    select(-c(V_go_M, V_fg_M, V_punt_M)) %>%
    relocate(V_go, .after= V_go_L) %>% relocate(V_fg, .after= V_fg_L) %>% relocate(V_punt, .after= V_punt_L) 
  Vs_all6
  
  return(Vs_all6)
}

# ### check
# calculate_Vs_bootstrap(ex2 

#################################################
### coachs' baseline decision model functions ###
#################################################

###
get_coach_decision_freqs <- function(fourth_down_dataset, coach_model) {
  ### XGBoost predictions
  p = pred_xgb_coach(coach_model, fourth_down_dataset)

  # p_fg_raw = pred_xgb_coach_fg(coach_model_fg, fourth_down_dataset)
  # p_punt_raw = pred_xgb_coach_punt(coach_model_punt, fourth_down_dataset)
  ### logistic regression predictions
  # p_fg_raw = predict(coach_model_fg, fourth_down_dataset, type="link")
  # p_punt_raw = predict(coach_model_punt, fourth_down_dataset, type="link")
  # p_fg_raw = exp(p_fg_raw)
  # p_punt_raw = exp(p_punt_raw)
  # p_raw = 1 + p_fg_raw + p_punt_raw
  # result = matrix(data = c(1/p_raw,  p_fg_raw/p_raw,  p_punt_raw/p_raw), ncol=3, byrow=FALSE)
  # colnames(result) = c("C_Go", "C_FG", "C_Punt")
  # result = as_tibble(result)
  
  result = as_tibble(p)
  result = result %>% 
    rowwise() %>%
    mutate(decision_coach_usual = case_when(
      C_Go == max(C_Go, C_FG, C_Punt) ~ "Go",
      C_FG == max(C_Go, C_FG, C_Punt) ~ "FG",
      C_Punt == max(C_Go, C_FG, C_Punt) ~ "Punt",
    )) %>%
    ungroup()
  result
}

###
get_coach_freqs_plot_df <- function(game_seconds_remaining, score_differential, coach_model) {
  plot_df = tibble()
  for (ytg in 1:15) {
    plot_df_ =  tibble(
      yardline_100 = 1:99,
      ydstogo = ytg,
      score_differential = score_differential,
      game_seconds_remaining = game_seconds_remaining, 
      posteam_spread = 0, 
      era_A=4
    )
    plot_df = bind_rows(plot_df, plot_df_)
  }
  ddf_coach = plot_df %>%
    mutate(get_coach_decision_freqs(., coach_model)) %>%
    rowwise() %>%
    mutate(decision = case_when(
      C_Go == max(C_Go, C_FG, C_Punt) ~ "Go",
      C_FG == max(C_Go, C_FG, C_Punt) ~ "FG",
      C_Punt == max(C_Go, C_FG, C_Punt) ~ "Punt",
    )) %>%
    mutate(decision_intensity = case_when(
      decision == "Go" ~ C_Go,
      decision == "FG" ~ C_FG,
      decision == "Punt" ~ C_Punt,
    )) 
  ddf_coach
}

############################
### Full Decision Making ###
############################

get_all_decision_making <- function(plays_df, wp, og_method=FALSE, SE=FALSE, b_max=B, coachBaseline=FALSE, custom_conv_prob=NULL) {
  if (SE) { ### decision making with bootstrapped standard errors
    Vs = calculate_Vs_bootstrap(plays_df, wp=wp, b_max=b_max, custom_conv_prob=custom_conv_prob)
  } else {
    Vs = calculate_Vs(plays_df, if (wp) V1_wp_model_obs else V1_model_obs, fg_model_obs, punt_model_obs, go_model_obs, og_method=og_method, wp=wp, custom_conv_prob=custom_conv_prob)
  }
  result = bind_cols(Vs, plays_df)
  result = result %>%
    mutate(get_coach_decision_freqs(., coach_model)) %>%
    mutate(V_baseline = C_Go*V_go + C_FG*V_fg + C_Punt*V_punt)
  if (coachBaseline) {
    result = result %>%
      rowwise() %>%
      mutate(V_actual = case_when(
        decision_actual == "Go" ~ V_go,
        decision_actual == "FG" ~ V_fg,
        decision_actual == "Punt" ~ V_punt,
      )) %>%
      ungroup() %>%
      mutate(V_added = V_actual - V_baseline) 
  }
  return(result)
}

get_full_decision_making <- function(play_df, wp, og_method=FALSE, SE=FALSE, b_max=B, coachBaseline=FALSE, custom_conv_prob=NULL) {
  
  kq = play_df$kq_0_sum_std
  pq = play_df$pq_0_sum_std
  pspread = play_df$posteam_spread
  qbqot = play_df$qbq_ot_0_sum
  oqrot = play_df$oq_rot_0_total_sum
  dqpdt = play_df$dq_dt_0_againstPass_sum 
  dqrdt = play_df$dq_dt_0_againstRun_sum 
  
  qbqdt = play_df$qbq_dt_0_sum
  oqrdt = play_df$oq_rdt_0_sum
  dqpot = play_df$dq_ot_0_againstPass_sum 
  dqrot = play_df$dq_ot_0_againstRun_sum 

  confounders_dataset = play_df %>% select(
    score_differential, scoreTimeRatio, game_seconds_remaining, home, receive_2h_ko,
    posteam_timeouts_remaining, defteam_timeouts_remaining,
    half_seconds_remaining, half_sec_rem_std, half, utm, era_A, 
    elapsed_share, spread_time, Diff_Time_Ratio,
  )
  
  dataset_V = generate_V_dataset(kq, pq, pspread, qbqot, oqrot, dqpdt, dqrdt, qbqdt, oqrdt, dqpot, dqrot, confounders_dataset)
  if (coachBaseline) {
    dataset_V$decision_actual = play_df$decision_actual
  }
  get_all_decision_making(dataset_V, wp, og_method=og_method, SE=SE, b_max=b_max, coachBaseline=coachBaseline, custom_conv_prob=custom_conv_prob) 
  
  # if (SE) { ### decision making with bootstrapped standard errors
  #   Vs = calculate_Vs_bootstrap(dataset_V, wp=wp, b_max=b_max)
  # } else {
  #   Vs = calculate_Vs(dataset_V, if (wp) V1_wp_model_obs else V1_model_obs, fg_model_obs, punt_model_obs, go_model_obs, og_method=og_method, wp=wp)
  # }
  # result = bind_cols(Vs, dataset_V)
  # return(result)
}

# ### check
# A = get_full_decision_making(kq=0, oqot=0, dqdt=0, oqdt=0, dqot=0, ex2_confounders_dataset,
#                              V1_model_main, og_method=FALSE, SE=FALSE)
# A
  
############
### plot ###
############ decision_intensity_0   prop_decision_A

plot_4thDownHeatmap <- function(decision_df, wp, og_method=FALSE, title=TRUE, legend_pos="right", SE=FALSE, coach=FALSE, ydl=NA, ytg=NA) {
  
  decision_df = decision_df %>% filter(ydstogo <= 10)
  
  # colrs <- c("Go" = "forestgreen", "FG" = "goldenrod2", "Punt" = "firebrick")
  colrs <- c("Go" = "darkgreen", "FG" = "darkgoldenrod", "Punt" = "darkred")
  # num_brks = 3
  
  fill_var = if (SE) "prop_decision" else "decision_intensity"
  
  # V_title = if (wp) "win probability" else "expected points"
  
  if (coach) {
    V_title = paste0(" baseline coach decision making frequencies\n with ",
                     decision_df$game_seconds_remaining[1], " sec. to go and score diff. = ", decision_df$score_differential[1])
    wp = TRUE
  } else if (SE) {
    V_title = paste0(" proportion of bootstrapped ", if (wp) "WP" else "EP", "\n models making that decision")
  } else {
    V_title = paste0(" ", if (wp) "win probability" else "expected points", 
                     " added by\n making that decision")
  }
  
  # browser()
  p = decision_df %>%
    ggplot(aes(x = yardline_100, y = ydstogo)) +
    geom_tile(data = . %>% filter(decision == "Go"), aes(fill = .data[[fill_var]])) +
    scale_fill_gradient2(low="white", high=colrs["Go"]) +
    # scale_fill_gradient2(low="white", high="darkgreen", breaks=scales::extended_breaks(n=num_brks)) +
    guides(fill = guide_legend(title=" Go", 
                               # direction = "horizontal", label.position = "bottom",
                               label.hjust = 0.5, label.vjust = 1, order = 1)) +
    new_scale_fill() +
    geom_tile(data = . %>% filter(decision == "FG"), aes(fill = .data[[fill_var]])) +
    scale_fill_gradient2(low="white", high=colrs["FG"]) +
    # scale_fill_gradient2(low="white", high="darkgoldenrod", breaks=scales::extended_breaks(n=num_brks)) +
    guides(fill = guide_legend(title=" FG", 
                               label.hjust = 0.5, label.vjust = 1, order = 1)) +
    new_scale_fill() +
    geom_tile(data = . %>% filter(decision == "Punt"), aes(fill = .data[[fill_var]])) +
    scale_fill_gradient2(low="white", high=colrs["Punt"]) +
    # scale_fill_gradient2(low="white", high="darkred", breaks=scales::extended_breaks(n=num_brks)) +
    guides(fill = guide_legend(title=" Punt", 
                               label.hjust = 0.5, label.vjust = 1, order = 1)) +
    geom_point(x=ydl, y=ytg, size=3, stroke=2, color="magenta", fill="white", shape=21)
  # p
  # browser()
  if (title) {
    p = p + labs(title=V_title)
  }
  p
  
  # if (title) {
  #   # p = p + labs(title = paste0(paste0("Fourth Down Decision Making using ", if (wp) "Win Probability" else "Expected Points"))) 
  #   p = p + labs(title = paste0(paste0(" fourth down decision making \n using ", V_title))) 
  # }
  
  if (SE) {
    p = p + scale_alpha_continuous(
      name = " proportion\n of\n bootstrapped\n models\n making\n that\n decision", 
      # breaks=seq(0,1,by=0.1)
    )
  } else {
    p = p + scale_alpha_continuous(
      name = paste0(" ", V_title, "\n added if", "\n make that", "\n decision"), 
    )
  }
  
  p = p +
    xlab("yardline") + ylab("yards to go") +
    scale_y_continuous(breaks=seq(1,10,by=1), minor_breaks = seq(1,10,by=1)) +
    scale_x_continuous(breaks=seq(10,90,by=10)) 
  
  if (legend_pos == "right") {
    p = p + theme(legend.direction = "vertical", legend.box = "vertical", legend.position="right") 
  } else if (legend_pos == "bottom") {
    p = p + theme(legend.direction = "horizontal", legend.box = "horizontal", legend.position="bottom") 
  } else if (legend_pos == "none") {
    p = p + guides(alpha = "none")
  } else if (legend_pos == "separate") {
    p = p + theme(
      legend.key.size = unit(1, 'cm'), #change legend key size
      # legend.key.height = unit(1, 'cm'), #change legend key height
      legend.key.height = unit(1/2, 'cm'), #change legend key height
      legend.key.width = unit(1/2, 'cm'), #change legend key width
      legend.title = element_text(size=12), #change legend title font size
      legend.text = element_text(size=10) #change legend text font size
    ) 
    legend = ggdraw(cowplot::get_legend(p))
    p = p + theme(legend.position="none") 
    return(list(plot = p, legend = legend))
  } 
  
  return(p)
}

textPlot <- function(plotname, string){
  # par(mar=c(0,0,0,0))
  # # pdf(paste0(plotname, ".pdf"))
  # png(paste0(plotname, ".png"))
  # plot(c(0, 1), c(0, 1), ann = F, bty = 'n', type = 'n', xaxt = 'n', yaxt = 'n')
  # text(x = 0.5, y = 0.5, paste(string), cex = 1, col = "black", family="serif", font=2, adj=0.5)
  # dev.off()
  strplot = ggplot() +
    annotate("text", x = 4, y = 25, size = 3, label = string) +
    theme_classic() + theme(
      axis.line=element_blank(),
      axis.text.x=element_blank(),
      axis.text.y=element_blank(),
      axis.ticks=element_blank(),
      axis.title.x=element_blank(),
      axis.title.y=element_blank(),
      legend.position="none",
    ) 
  ggsave(paste0(plotname, ".png"), strplot)
}

#########################################
### plot the V_go, V_fg, V_punt lines ###
#########################################

plot_Vs <- function(ddf, ytg, SE=FALSE, include_og=FALSE, wp=FALSE) {
  ddf_iytg = ddf %>% filter(ydstogo == ytg)
  ddf_iytg = ddf_iytg %>% mutate(V_punt = ifelse(yardline_100 <= 30, NA, V_punt))
  if (SE) {
    ddf_iytg = ddf_iytg %>% mutate(V_punt_L = ifelse(yardline_100 <= 30, NA, V_punt_L))
    ddf_iytg = ddf_iytg %>% mutate(V_punt_U = ifelse(yardline_100 <= 30, NA, V_punt_U))
  }
  
  plot_title = paste0(ytg, " yards to go")
  
  breaks=seq(-7,7,by=1)
  ylab_ = "expected points"
  if (wp) {
    y_max = 1
    y_min = 0
    breaks = seq(-1,1,by=0.2)
    ylab_ = "win probability"
  } else if (SE) { ### bootstrapped standard errors
    y_max = max(c(ddf_iytg$V_fg_U, ddf_iytg$V_go_U, ddf_iytg$V_punt_U), na.rm=TRUE)+0.2
    y_min = min(c(ddf_iytg$V_fg_U, ddf_iytg$V_go_U, ddf_iytg$V_punt_U), na.rm=TRUE)
  } else {
    y_max = max(c(ddf_iytg$V_fg, ddf_iytg$V_go, ddf_iytg$V_punt), na.rm=TRUE)#+0.2
    y_min = min(c(ddf_iytg$V_fg, ddf_iytg$V_go, ddf_iytg$V_punt), na.rm=TRUE)
  }
  plot_decision = ddf_iytg %>%
    ggplot(aes(x=yardline_100)) +
    geom_line(aes(y = V_punt, color="Punt"), size=1) +
    geom_line(aes(y = V_fg, color="FG"), size=1) +
    geom_line(aes(y = V_go, color="Go"), size=1) +
    scale_color_manual(name="", values=c("Punt"="firebrick", "Go"="forestgreen", "FG"="goldenrod2")) +
    labs(title=plot_title) +
    xlab("yardline") + ylab(ylab_) +
    scale_x_continuous(breaks=seq(0,100,by=10), limits=c(0,100)) +
    scale_y_continuous(breaks=breaks, 
                       limits=c(y_min,y_max)
                       # limits=c(y_min-1,y_max+1.5)
    )
  plot_decision
  
  if (SE) { ### bootstrapped standard errors
    plot_decision = plot_decision + 
      geom_line(aes(y = V_punt_L), linetype="dashed", color="firebrick") +
      geom_line(aes(y = V_punt_U), linetype="dashed", color="firebrick") +
      geom_line(aes(y = V_fg_L), linetype="dashed", color="goldenrod2") +
      geom_line(aes(y = V_fg_U), linetype="dashed", color="goldenrod2") +
      geom_line(aes(y = V_go_L), linetype="dashed", color="forestgreen") +
      geom_line(aes(y = V_go_U), linetype="dashed", color="forestgreen")
  } else {
    
  }
  
  if (include_og) { ### include decision making of the original method
    plot_decision = plot_decision +
      geom_line(aes(y = V_PUNT_og), color="darkred", size=1) +
      geom_line(aes(y = V_FG_og), color="goldenrod4", size=1) +
      geom_line(aes(y = V_GO_og), size=1, color="darkgreen")
  }
  plot_decision
  
  # plot_decision = plot_decision +
  #   annotation_custom(
  #     grobTree(textGrob("Right Decision Making", x=0.05,  y=0.955, hjust=0,
  #                       gp=gpar(col="black", fontsize=12,fontface="italic")))
  #   ) +
  #   annotation_custom(
  #     grobTree(textGrob( paste0("Previous ", "Decision Making"),  ##"Naive Decision Making",
  #                        x=0.05,  y=0.865, hjust=0, gp=gpar(col="black", fontsize=12,fontface="italic")))
  #   )
  # plot_decision
  # 
  # get_color <- function(x) {
  #   sapply(x, FUN = function(j) {
  #     case_when(
  #       j == "FG" ~ "orange2",
  #       j == "Go" ~ "seagreen3",
  #       j == "Punt" ~ "firebrick3",
  #       TRUE ~ "gray70"
  #     )
  #   })
  # }
  # 
  # ddf_iytg$decision_right_color = get_color(ddf_iytg$decision)
  # ddf_iytg$decision_prev_color = get_color1(ddf_iytg$decision_prev)
  # plot_decision = plot_decision + geom_segment(aes(x=yardline_100, xend=yardline_100, yend=y_max+1.5-0.3, y=y_max+1.5-0.6),
  #                                              color = ex1a$decision_right_color, size=2.5)
  # plot_decision = plot_decision + geom_segment(aes(x=yardline_100, xend=yardline_100, yend=y_max+1.5-1.1, y=y_max+1.5-1.4),
  #                                              color = ex1a$decision_prev_color, size=2.5)
  
  return(plot_decision)
}

# plot_Vs(ddf_i, ytg=4)

plot_V_vs_ydstogo <- function(ddf, ytg, ydl, SE=FALSE, include_og=FALSE, wp=FALSE) {
  ddf_iytg = ddf %>% filter(yardline_100 == ydl)
  
  plot_title = paste0(ydl, " yardline")
  
  breaks=seq(-7,7,by=1)
  ylab_ = "expected points"
  if (wp) {
    y_max = 1
    y_min = 0
    breaks = seq(-1,1,by=0.02)
    ylab_ = "win probability"
  } else if (SE) { ### bootstrapped standard errors
    y_max = max(c(ddf_iytg$V_fg_U, ddf_iytg$V_go_U, ddf_iytg$V_punt_U), na.rm=TRUE)+0.2
    y_min = min(c(ddf_iytg$V_fg_U, ddf_iytg$V_go_U, ddf_iytg$V_punt_U), na.rm=TRUE)
  } else {
    y_max = max(c(ddf_iytg$V_fg, ddf_iytg$V_go, ddf_iytg$V_punt), na.rm=TRUE)#+0.2
    y_min = min(c(ddf_iytg$V_fg, ddf_iytg$V_go, ddf_iytg$V_punt), na.rm=TRUE)
  }
  # max_wp= max(
  #   (ddf_iytg %>% filter(ydstogo==ytg))$V_go,
  #   (ddf_iytg %>% filter(ydstogo==ytg))$V_punt,
  #   (ddf_iytg %>% filter(ydstogo==ytg))$V_fg
  # )
  plot_decision = ddf_iytg %>%
    ggplot(aes(x=ydstogo)) +
    geom_line(aes(y = V_punt), color="firebrick", size=1) +
    geom_line(aes(y = V_fg), size=1, color="goldenrod2") +
    geom_line(aes(y = V_go), size=1, color="forestgreen") +
    # geom_point(x=ytg, y = max_wp, size=3, stroke=2, color="magenta", fill="white", shape=21) +
    geom_vline(xintercept=ytg, linetype="dotted") +
    labs(title=plot_title) +
    xlab("yards to go") + ylab(ylab_) +
    # scale_y_continuous(breaks=breaks,
    #                    # limits=c(y_min,y_max)
    # ) +
    scale_x_continuous(breaks=seq(1,10,by=1), limits=c(1,10)) 
  plot_decision
  
  if (SE) { ### bootstrapped standard errors
    plot_decision = plot_decision + 
      geom_line(aes(y = V_punt_L), linetype="dashed", color="firebrick") +
      geom_line(aes(y = V_punt_U), linetype="dashed", color="firebrick") +
      geom_line(aes(y = V_fg_L), linetype="dashed", color="goldenrod2") +
      geom_line(aes(y = V_fg_U), linetype="dashed", color="goldenrod2") +
      geom_line(aes(y = V_go_L), linetype="dashed", color="forestgreen") +
      geom_line(aes(y = V_go_U), linetype="dashed", color="forestgreen")
  } else {
    
  }
  
  if (include_og) { ### include decision making of the original method
    plot_decision = plot_decision +
      geom_line(aes(y = V_PUNT_og), color="darkred", size=1) +
      geom_line(aes(y = V_FG_og), color="goldenrod4", size=1) +
      geom_line(aes(y = V_GO_og), size=1, color="darkgreen")
  }
  plot_decision
  
  # plot_decision = plot_decision +
  #   annotation_custom(
  #     grobTree(textGrob("Right Decision Making", x=0.05,  y=0.955, hjust=0,
  #                       gp=gpar(col="black", fontsize=12,fontface="italic")))
  #   ) +
  #   annotation_custom(
  #     grobTree(textGrob( paste0("Previous ", "Decision Making"),  ##"Naive Decision Making",
  #                        x=0.05,  y=0.865, hjust=0, gp=gpar(col="black", fontsize=12,fontface="italic")))
  #   )
  # plot_decision
  # 
  # get_color <- function(x) {
  #   sapply(x, FUN = function(j) {
  #     case_when(
  #       j == "FG" ~ "orange2",
  #       j == "Go" ~ "seagreen3",
  #       j == "Punt" ~ "firebrick3",
  #       TRUE ~ "gray70"
  #     )
  #   })
  # }
  # 
  # ddf_iytg$decision_right_color = get_color(ddf_iytg$decision)
  # ddf_iytg$decision_prev_color = get_color1(ddf_iytg$decision_prev)
  # plot_decision = plot_decision + geom_segment(aes(x=yardline_100, xend=yardline_100, yend=y_max+1.5-0.3, y=y_max+1.5-0.6),
  #                                              color = ex1a$decision_right_color, size=2.5)
  # plot_decision = plot_decision + geom_segment(aes(x=yardline_100, xend=yardline_100, yend=y_max+1.5-1.1, y=y_max+1.5-1.4),
  #                                              color = ex1a$decision_prev_color, size=2.5)
  
  return(plot_decision)
}

plot_4th_down_lookahead <- function(ddf, ydl, SE=FALSE, boot_plot=FALSE, wp=FALSE) {
  ytg_ = ifelse(ydl < 10, ydl, 10)
  ddf_lookahead = ddf %>% 
    # filter(ydstogo)
    filter(ydl-9 <= yardline_100 & yardline_100 <= ydl+5) %>%
    arrange(-yardline_100) %>%
    filter(ydl - ytg_ == yardline_100 - ydstogo)
  ddf_lookahead = ddf_lookahead %>% mutate(V_punt = ifelse(yardline_100 <= 30, NA, V_punt))
  ddf_lookahead
  
  if (SE) {
    ddf_lookahead = ddf_lookahead %>% mutate(V_punt_L = ifelse(yardline_100 <= 30, NA, V_punt_L))
    ddf_lookahead = ddf_lookahead %>% mutate(V_punt_U = ifelse(yardline_100 <= 30, NA, V_punt_U))
  }
  
  # browser()
  
  # scorediff = unique(ddf_lookahead$score_differential)
  # a1 = case_when(scorediff < 0 ~ "Down", scorediff > 0 ~ "Up", TRUE ~ "Tied Up")
  plot_title = paste0("4th Down Look-Ahead\n", "1st Down at ", ydl)
  
  if (boot_plot) {
    plot_decision = ddf_lookahead %>%
      ggplot(aes(x=ydstogo)) +
      geom_line(aes(y = boot_prop_punt, color="Punt"), size=1) +
      geom_line(aes(y = boot_prop_fg, color="FG"), size=1) +
      geom_line(aes(y = boot_prop_go, color="Go"), size=1) +
      scale_color_manual(name="", values=c("Punt"="firebrick", "Go"="forestgreen", "FG"="goldenrod2")) +
      labs(title=plot_title) +
      xlab("yards to go") + ylab("bootstrap proportion") +
      scale_y_continuous(breaks=seq(0,1,by=0.1), limits=c(0,1)) +
      scale_x_continuous(
        breaks=seq(1,15,by=2),
        sec.axis = sec_axis(~.x+ydl-ytg_, breaks = seq(ydl-100,ydl+100,by=5), name="yardline")
      ) 
    plot_decision
    return(plot_decision)
  }

  ####################
  breaks=seq(-7,7,by=1)
  ylab_ = "expected points"
  if (wp) {
    y_max = 1
    y_min = 0
    breaks = seq(-1,1,by=0.02)
    ylab_ = "win probability"
  } else if (SE) { ### bootstrapped standard errors
    y_max = max(c(ddf_lookahead$V_fg_U, ddf_lookahead$V_go_U, ddf_lookahead$V_punt_U), na.rm=TRUE)+0.2
    y_min = min(c(ddf_lookahead$V_fg_U, ddf_lookahead$V_go_U, ddf_lookahead$V_punt_U), na.rm=TRUE)
  } else {
    y_max = max(c(ddf_lookahead$V_fg, ddf_lookahead$V_go, ddf_lookahead$V_punt), na.rm=TRUE)#+0.2
    y_min = min(c(ddf_lookahead$V_fg, ddf_lookahead$V_go, ddf_lookahead$V_punt), na.rm=TRUE)
  }
  # browser()
  plot_decision = ddf_lookahead %>%
    ggplot(aes(x=ydstogo)) +
    geom_line(data=.%>%drop_na(V_punt), aes(y = V_punt, color="Punt"), size=1, na.rm = TRUE) +
    geom_line(aes(y = V_fg, color="FG"), size=1) +
    geom_line(aes(y = V_go, color="Go"), size=1) +
    scale_color_manual(name="", values=c("Punt"="firebrick", "Go"="forestgreen", "FG"="goldenrod2")) +
    labs(title=plot_title) +
    xlab("yards to go") + ylab(ylab_) +
    scale_x_continuous(
      breaks=seq(1,15,by=2),
      sec.axis = sec_axis(~.x+ydl-ytg_, breaks = seq(ydl-100,ydl+100,by=5), name="yardline")
    ) 
  plot_decision
 
  if (SE) { ### bootstrapped standard errors
    plot_decision = plot_decision +
      geom_line(data=.%>%drop_na(V_punt), aes(y = V_punt_L), linetype="dashed", color="firebrick") +
      geom_line(data=.%>%drop_na(V_punt), aes(y = V_punt_U), linetype="dashed", color="firebrick") +
      geom_line(aes(y = V_fg_L), linetype="dashed", color="goldenrod2") +
      geom_line(aes(y = V_fg_U), linetype="dashed", color="goldenrod2") +
      geom_line(aes(y = V_go_L), linetype="dashed", color="forestgreen") +
      geom_line(aes(y = V_go_U), linetype="dashed", color="forestgreen")
  }
  plot_decision
  
  return(plot_decision)
}

################
### decision ###
################

get_decision <- function(ydl, ytg, decision_df, include_uncertainty=FALSE, p_cutoff = P_CUTOFF) {
  df_ = decision_df %>% filter(yardline_100 == ydl & ydstogo == ytg)
  result_ = list(decision = df_$decision)
  if (include_uncertainty) {
    result_$decision_intensity = df_$decision_intensity
    # result_$decision_confidence = df_$prop_decision > p_cutoff
    result_$decision_confidence = df_$prop_decision
    # browser()
    result_$decision_V_gain_L = df_$V_gain_L
    result_$decision_V_gain_U = df_$V_gain_U
    # result_$decision_wp_L = df_$decision_intensity_L
    # result_$decision_wp_U = df_$decision_intensity_U
    # result_$decision_wp_L = df_[[paste0("V_", tolower(result_$decision), "_L")]]
    # result_$decision_wp_U = df_[[paste0("V_", tolower(result_$decision), "_U")]]
    # browser()
  } else {
    result_$decision_intensity = df_$decision_intensity
  }
  return(result_)
}

plot_gt_4th_down_summary <- function(play_df, ddf, decision_df=NULL, SE=FALSE, wp=TRUE) {
  plot_gt_4th_down_summary
  a1 = paste0(
    if (play_df$score_differential < 0) "Down " else if (play_df$score_differential > 0) "Up " else "Tied Up", if (play_df$score_differential!=0) abs(play_df$score_differential),
    ", 4th & ", play_df$ydstogo, ", ", play_df$yardline_100, " yards from opponent endzone"
  )
  a1
  
  play_df$qtr
  qtr_sec_rem = play_df$game_seconds_remaining - (4-play_df$qtr)*900
  qtr_min_rem = floor(qtr_sec_rem / 60)
  qtr_sec_str_rem = qtr_sec_rem %% 60
  qtr_sec_str_rem = if (nchar(qtr_sec_str_rem) == 1) paste0("0", qtr_sec_str_rem) else qtr_sec_str_rem
  a2 = paste0(
    "Qtr ", play_df$qtr, ", ", qtr_min_rem, ":", qtr_sec_str_rem, " | ", 
    "Timeouts: Off ", play_df$posteam_timeouts_remaining, ", Def ", play_df$defteam_timeouts_remaining, " | ",
    "Point Spread: ", play_df$posteam_spread
  )
  a2
  
  ddf_i_i = ddf %>% filter(yardline_100==play_df$yardline_100 & ydstogo==play_df$ydstogo)
  a3 = tibble("decision" = c("Go for it", "Field goal", "Punt"))
  wpstr = if (wp) "WP" else "EP"
  a3[[wpstr]] = c(ddf_i_i$V_go, ddf_i_i$V_fg, ddf_i_i$V_punt)
  boot_perc_str = "boot %"
  if (SE) {
    a3[[boot_perc_str]] = c(ddf_i_i$boot_prop_go, ddf_i_i$boot_prop_fg, ddf_i_i$boot_prop_punt)
  }
  a3[["success prob"]] = c(ddf_i_i$p_convert, ddf_i_i$p_fg, NA)
  a3[[paste0(wpstr, " if fail")]] = c(ddf_i_i$v_dont_convert, ddf_i_i$v_miss_fg, NA)
  a3[[paste0(wpstr, " if succeed")]] = c(ddf_i_i$v_convert, ddf_i_i$v_make_fg, NA)
  a3[["baseline coach %"]] = c(ddf_i_i$C_Go, ddf_i_i$C_FG, ddf_i_i$C_Punt)
  # a3 = if (play_df$yardline_100 <= 40) a3 %>% filter(decision != "Punt") else a3
  # a3 = if (play_df$yardline_100 >= 51) a3 %>% filter(decision != "Field goal") else a3
  a3 = a3 %>% round_df(digits=3)
  a3 = a3 %>% arrange(-!!sym(wpstr))
  if (SE) {
    # v_gain_ci_str = paste0(
    #   "[", round(decision_df$decision_wp_L*100,3), "%, ", round(decision_df$decision_wp_U*100,3), "%]"
    # )
    v_gain_ci_str = paste0(
      "[", round(decision_df$decision_V_gain_L, 5), ", ", round(decision_df$decision_V_gain_U, 5), "]"
    )
    a3[[paste0(wpstr, " gain CI")]] = c(v_gain_ci_str, rep("", nrow(a3)-1))
    a3 = a3 %>% relocate(!!paste0(wpstr, " gain CI"), .before=boot_perc_str)
  }
  a3
  
  # output$decision_wp_CI = renderText({ 
  #   paste0("decision adds wp CI: [", paste0(round(decision_wp$decision_wp_L*100,3), "%, ", round(decision_wp$decision_wp_U*100,3), "%]", " win probility") )
  # })
  
  library(gt)
  library(paletteer)
  
  aaa = gt(a3) %>% tab_header(
    title=a1,
    subtitle=a2
  ) %>% data_color(
    columns = c(wpstr),
    colors = scales::col_numeric(
      palette = paletteer::paletteer_d(
        palette = c("ggsci::blue_material")
      ) %>% as.character(),
      domain = range(a3[[wpstr]]) + c(-0.01, 0.01)
      # domain = NULL
      # domain = if (wp) c(0,1) else NULL
    )
  ) 
  if (SE) {
    aaa = aaa %>%
      data_color(
        columns = c(`boot %`),
        colors = scales::col_numeric(
          palette = paletteer::paletteer_d(
            palette = c("ggsci::orange_material")
          ) %>% as.character(),
          # domain = NULL
          domain = c(0,1)
        )
      )
  }
  aaa = aaa %>% tab_options(
    table.width = pct(85)
  ) %>% sub_missing(
    columns = everything(),
    rows = everything(),
    missing_text=""
  )
  return(aaa)
}






# plot_4thDownHeatmap <- function(decision_df, wp, og_method=FALSE, title=TRUE, legend_pos="right", SE=FALSE) {
#   
#   if (SE) { 
#     p = decision_df %>%
#       ggplot(aes(x = yardline_100, y = ydstogo, fill=decision, alpha=prop_decision))
#   } else {
#     p = decision_df %>%
#       ggplot(aes(x = yardline_100, y = ydstogo, fill=decision, alpha=decision_intensity))
#   }
#    
#   colrs <- c("Go" = "forestgreen", "FG" = "goldenrod2", "Punt" = "firebrick")
#   p = p +
#     geom_tile(data = . %>% filter(decision == "Go")) +
#     geom_tile(data = . %>% filter(decision == "FG")) +
#     geom_tile(data = . %>% filter(decision == "Punt")) + 
#     scale_fill_manual(values = colrs)
#   
#   # alpha_min <- min(decision_df$decision_intensity)
#   # alpha_max <- max(decision_df$decision_intensity)
#   # numbreaks <- 3
#   # breaks = round(seq(from = alpha_min, to = alpha_max, by = (alpha_max - alpha_min) / numbreaks), 2)
#   
#   
#   V_title = if (wp) "win probability" else "expected points"
# 
#   if (SE) {
#     p = p + scale_alpha_continuous(
#       name = " proportion\n of\n bootstrapped\n models\n making\n that\n decision", 
#       # breaks=seq(0,1,by=0.1)
#     )
#   } else {
#     p = p + scale_alpha_continuous(
#       name = paste0(" ", V_title, "\n added if", "\n make that", "\n decision"), 
#     )
#   }
#   
#   p = p +
#     xlab("yardline") + ylab("yards to go") +
#     scale_y_continuous(breaks=seq(0,20,by=1), minor_breaks = seq(0,20,by=1)) +
#     scale_x_continuous(breaks=seq(0,100,by=10)) 
# 
#   if (title) {
#     # p = p + labs(title = paste0(paste0("Fourth Down Decision Making using ", if (wp) "Win Probability" else "Expected Points"))) 
#     p = p + labs(title = paste0(paste0(" fourth down decision making \n using ", V_title))) 
#   }
#   
#   if (legend_pos == "right") {
#     p = p + theme(legend.direction = "vertical", legend.box = "vertical", legend.position="right") 
#   } else if (legend_pos == "bottom") {
#     p = p + theme(legend.direction = "horizontal", legend.box = "horizontal", legend.position="bottom") 
#   } else if (legend_pos == "none") {
#     p = p + guides(alpha = "none")
#   } else if (legend_pos == "separate") {
#     p = p + theme(
#       legend.key.size = unit(1, 'cm'), #change legend key size
#       # legend.key.height = unit(1, 'cm'), #change legend key height
#       legend.key.height = unit(1/2, 'cm'), #change legend key height
#       legend.key.width = unit(1/2, 'cm'), #change legend key width
#       legend.title = element_text(size=12), #change legend title font size
#       legend.text = element_text(size=10) #change legend text font size
#     ) 
#     legend = ggdraw(cowplot::get_legend(p))
#     p = p + theme(legend.position="none") 
#     return(list(plot = p, legend = legend))
#   } 
#   
#   return(p)
# }




# plot_4thDownHeatmap_SE_OLD <- function(decision_df, wp, og_method=FALSE, title=TRUE, legend_pos="right", p_cutoff = P_CUTOFF) {
#   conf_str = paste0("\n (< ", p_cutoff*100, "% \n confidence)")
#   decision_df_A = decision_df %>%
#     mutate(decision1 = case_when(
#       decision == "Go" & prop_decision >= p_cutoff ~ "Go",
#       decision == "Punt" & prop_decision >= p_cutoff ~ "Punt",
#       decision == "FG" & prop_decision >= p_cutoff ~ "FG",
#       decision == "Go" & prop_decision < p_cutoff ~ "GoL",
#       decision == "Punt" & prop_decision < p_cutoff ~ "PuntL",
#       decision == "FG" & prop_decision < p_cutoff ~ "FGL",
#       TRUE ~ NA_character_
#     )) 
#   colrs <- c(
#     "Go" = "darkgreen", "GoL" = "darkolivegreen1",
#     "FG" = "darkgoldenrod", "FGL" = "yellow1",
#     "Punt" = "darkred", "PuntL" = "plum1"
#   )
#   
#   # browser()
#   
#   num_brks = 3
#   
#   p = decision_df_A %>%
#     ggplot(aes(x = yardline_100, y = ydstogo)) +
#     theme(legend.text = element_text(face = "bold", size=0)) +
#     ##################
#   geom_tile(data = . %>% filter(decision1 == "Go"), aes(fill = decision_intensity_0)) +
#     # scale_fill_gradient2(low="white", high="darkgreen", breaks=seq(0,5,by=0.25)) +
#     scale_fill_gradient2(low="white", high="darkgreen", breaks=scales::extended_breaks(n=num_brks)) +
#     # scale_fill_gradient2(low="white", high="darkgreen") +
#     guides(fill = guide_legend(title=" Go", direction = "horizontal", label.position = "bottom",
#                                label.hjust = 0.5, label.vjust = 1, order = 1)) +
#     # guides(fill = guide_legend(title=" Go decision intensity", #nrow=1,
#     #                            label.hjust = 0.5, label.vjust = 1, order = 1,
#     #                            direction = "horizontal", label.position = "bottom")) +
#     ##################
#   new_scale_fill() +
#     geom_tile(data = . %>% filter(decision1 == "FG"), aes(fill = decision_intensity_0)) +
#     # scale_fill_gradient2(low="white", high="darkgoldenrod", breaks=seq(0,5,by=0.25)) +
#     scale_fill_gradient2(low="white", high="darkgoldenrod", breaks=scales::extended_breaks(n=num_brks)) +
#     guides(fill = guide_legend(title=" FG", #nrow=1,
#                                label.hjust = 0.5, label.vjust = 1, order = 3,
#                                direction = "horizontal", label.position = "bottom")) +
#     ##################
#   new_scale_fill() +
#     geom_tile(data = . %>% filter(decision1 == "Punt"), aes(fill = decision_intensity_0)) +
#     # scale_fill_gradient2(low="white", high="darkred", breaks=seq(0,5,by=0.25)) +
#     scale_fill_gradient2(low="white", high="darkred", breaks=scales::extended_breaks(n=num_brks)) +
#     guides(fill = guide_legend(title=" Punt", #nrow=1,
#                                label.hjust = 0.5, label.vjust = 1, order = 5,
#                                direction = "horizontal", label.position = "bottom")) +
#     xlab("yardline") + ylab("yards to go") +
#     scale_alpha_continuous(breaks=seq(0,10,by=0.25)) +
#     scale_y_continuous(breaks=seq(0,20,by=1), minor_breaks = seq(0,20,by=1)) +
#     scale_x_continuous(breaks=seq(0,100,by=10)) +
#     ##################
#   new_scale_fill() +
#     geom_tile(data = . %>% filter(decision1 == "GoL"), aes(fill = decision_intensity_0)) +
#     # geom_tile(data = . %>% filter(decision1 == "GoL"), aes(fill = prop_decision)) +
#     guides(fill = guide_legend(title=paste0(" Go ",conf_str,""), #nrow=1,
#                                label.hjust = 0.5, label.vjust = 1, order = 2,
#                                direction = "horizontal", label.position = "bottom")) +
#     scale_fill_gradient2(low="white", high="darkolivegreen1", breaks=scales::extended_breaks(n=num_brks)) + 
#     ##################
#   new_scale_fill() +
#     geom_tile(data = . %>% filter(decision1 == "FGL"), aes(fill = decision_intensity_0)) +
#     # geom_tile(data = . %>% filter(decision1 == "FGL"), aes(fill = prop_decision)) +
#     # scale_fill_gradient2(low="white", high="yellow1") +
#     # scale_fill_gradient2(low="white", high="gold") +
#     # scale_fill_gradient2(low="white", high="lightgoldenrod1") +
#     scale_fill_gradient2(low="white", high="khaki1", breaks=scales::extended_breaks(n=num_brks)) +
#     # scale_fill_gradient2(low="white", high="peachpuff2") +
#     # scale_fill_gradient2(low="white", high="navajowhite") +
#     guides(fill = guide_legend(title=paste0(" FG ",conf_str,""), #nrow=1,
#                                label.hjust = 0.5, label.vjust = 1, order = 4,
#                                direction = "horizontal", label.position = "bottom")) +
#     ##################
#   new_scale_fill() +
#     geom_tile(data = . %>% filter(decision1 == "PuntL"), aes(fill = decision_intensity_0)) +
#     # geom_tile(data = . %>% filter(decision1 == "PuntL"), aes(fill = prop_decision)) +
#     scale_fill_gradient2(low="white", high="plum1", breaks=scales::extended_breaks(n=num_brks)) +
#     guides(fill = guide_legend(title=paste0(" Punt ",conf_str,""), #nrow=1,
#                                label.hjust = 0.5, label.vjust = 1, order = 6,
#                                direction = "horizontal", label.position = "bottom"))
#   
#   if (title) {
#     # p = p + labs(title = paste0(paste0("Fourth Down Decision Making using ", if (wp) "Win Probability" else "Expected Points")))
#     p = p + labs(title = paste0(paste0(" Fourth Down Decisions Using \n", 
#                                        if (wp) "Win Probability" else "Expected Points")))
#   }
#   
#   if (legend_pos == "bottom") {
#     p = p + theme(legend.direction = "horizontal", legend.box = "horizontal", legend.position="bottom") 
#   } else if (legend_pos == "right") {
#     p = p + theme(legend.direction = "horizontal", legend.box = "vertical", legend.position="right") 
#   } else if (legend_pos == "none") {
#     p = p + theme(legend.position="none") 
#   } else if (legend_pos == "separate") {
#     p = p + theme(legend.direction = "vertical", legend.box = "vertical", legend.position="right") 
#     p = p + theme(
#       legend.key.size = unit(1/3, 'cm'), #change legend key size
#       legend.key.height = unit(1/3, 'cm'), #change legend key height
#       legend.key.width = unit(1/3, 'cm'), #change legend key width
#       legend.title = element_text(size=8), #change legend title font size
#       legend.text = element_text(size=6) #change legend text font size
#     ) 
#     legend = ggdraw(cowplot::get_legend(p))
#     p = p + theme(legend.position="none") 
#     return(list(plot = p, legend = legend))
#   } 
#   
#   return(p)
# }
